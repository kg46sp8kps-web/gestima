# Gestima — Session Learning Log

Tento soubor se automaticky plní po každé session (Stop hook s type:agent).
Claude Code ho čte na začátku KAŽDÉ session = persistentní paměť.

---

## Session 2026-02-04 (initial setup)
- **Změny:** Kompletní refaktor agent systému
- **Poučení:** .md dokumentace ≠ enforcement. Hooks (bash skripty) jsou jediný spolehlivý způsob vynucování pravidel. CLAUDE.md AI může ignorovat, hook ne.
- **Anti-patterns:** Dokumentační divadlo — 2200 řádků popisujících neexistující Python framework (agents.config.yaml s temperature, max_tokens, AgentPool)
- **Co funguje:** YAML frontmatter v .claude/agents/*.md s `disallowedTools` pro reálné omezení nástrojů. Skills pro context injection místo Librarian agenta.
- **NEOPAKOVAT:** Nabízet řešení a vzápětí ho nabídnout smazat. Být konzistentní.

## Session 2026-02-04 (feature recognition v3 - point-based contour)
- **Změny:** Kompletní přepis profile_geometry promptu a SVG rendereru
  - `step_pdf_parser.py` — prompt změněn z block modelu (`sections[]`) na point-based konturu (`outer_contour: [{r, z}]`, `inner_contour: [{r, z}]`, `holes: [...]`)
  - `profile_svg_renderer.py` — kompletní rewrite z rect-based (~566 LOC) na path-based (~471 LOC), `<path>` z bodů, zrcadlení kolem CL
  - API vrací 28-bodovou konturu s kužely, filety, zkoseními — vs. staré 3 sekce obdélníků
- **Poučení:**
  - Block model (sections s outer_diameter) NEMŮŽE vyjádřit kužely, filety, zkosení → vždy "čtverce"
  - Point-based konturu Claude vrací přirozeně — 6 bodů pro 31° kužel, 12 bodů pro 82° kužel
  - Prompt MUSÍ obsahovat konkrétní příklad reálného dílu (hřídel Ø30 s přírubou Ø55) — bez příkladu Claude hádá formát
  - Dimension labels: zobrazovat POUZE stabilní segmenty (stejné r ±0.2mm pro po sobě jdoucí body, segment > 0.5mm), ne přechodové body kuželů
  - API bez PDF kontextu vrací nesmysly (celý díl Ø55 jako trubka) — VŽDY posílat PDF!
- **Anti-patterns:**
  - Prompt přepisován 3× než dosáhl správného formátu — příště: napřed definovat výstupní JSON schéma, pak psát prompt
  - Test pipeline hledal soubory ve špatném adresáři (`drawings/` vs `uploads/drawings/`) — hardcode explicitní cesty v testech
- **Co funguje:** Single-agent přístup pro 2 soubory (step_pdf_parser.py + profile_svg_renderer.py). Nepotřeba ŠÉFÍK.
- **Startovní bod:** Tento prompt + renderer = baseline pro ladění feature recognition. Vše "běží".
